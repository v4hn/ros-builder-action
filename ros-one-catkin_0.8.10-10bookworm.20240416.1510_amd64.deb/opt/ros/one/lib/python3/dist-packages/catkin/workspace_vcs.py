# for backward compatibility
from catkin_pkg.workspace_vcs import *  # noqa
